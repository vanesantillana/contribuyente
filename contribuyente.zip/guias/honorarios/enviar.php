          	<form role="form" action="honorario.php" method="post" target="_blank"> 
          	

				              <label >nombre1:</label>
				              <input type="text" name="nombre1">
				              <br>
				              <label > ruc1:</label>
				              <input type="text" name="ruc1" >
				              <br>
				              <label >direccion1 </label>
				              <input type="text"  name="direccion1" >
				              <br>
				              <label > nombre2:</label>
				              <input type="text" name="nombre2">
				              <br>
				              <label > ruc2</label>
				              <input type="text"  name="ruc2">
				              <br>
				              <label > direccion2</label>
				              <input type="text"  name="direccion2">
				              <br>
				              <label > suma</label>
				              <input type="text"  name="suma">
				              <br>
				              <label > concepto</label>
				              <input type="text"  name="concepto">
				              <br>
				              <label > observacion</label>
				              <input type="text"  name="observacion">
				              <br>
				              <label > inciso</label>
				              <input type="text"  name="inciso">
				              <br>
				              <label > fecha</label>
				              <input type="text"  name="fecha">
				              <br>
				              <label > total</label>
				              <input type="text"  name="total">
				              <br>

				              <input type="submit" value="Generar PDF" name="submit" />			                     
				        </form> 