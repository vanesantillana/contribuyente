<div class="modal fade" id="myModal6" role="dialog">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header" style="background-color:#0b5394">
				<button type="button" style="color:#FFFFFF" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title" style="color:#FFFFFF" align="center"><strong>Conversor de moneda</strong></h4>
			</div>
			<div class="modal-body">
				<iframe id="tmccc" src="http://themoneyconverter.com/ES/CurrencyConverter.aspx?tab=0&amp;from=PEN&amp;to=USD&amp;bg=ffffff" style="width:350px; height:400px; border: none;" scrolling="no" marginwidth="0" marginheight="0"></iframe>
			</div>
		</div>

	</div>
</div>
