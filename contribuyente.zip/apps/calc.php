<div class="modal fade" id="myModal7" role="dialog" >
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header" style="background-color:#0b5394">
				<button type="button" style="color:#FFFFFF" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title" style="color:#FFFFFF" align="center"><strong>Calculadora Tributaria</strong></h4>
			</div>
			<div class="modal-body embed-container">
				<iframe src="http://www.sunat.gob.pe/cl-at-itcalculibre/actdeuS01Alias#ayudaUsuario" width="770" height="600" scrolling="no" frameborder="0"></iframe>
			</div>
		</div>

	</div>
</div>